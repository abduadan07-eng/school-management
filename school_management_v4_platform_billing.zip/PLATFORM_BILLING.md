# Platform Billing

The app uses a platform-owner billing model.

## Flow
1. Super Admin registers a school.
2. Super Admin creates/activates the school's subscription.
3. Super Admin sets the plan, amount, start date and end date.
4. When the school pays, Super Admin records the payment.
5. The school remains active while its subscription is active.
6. Super Admin can renew/extend the subscription by updating the subscription dates.
7. Expired/inactive schools can be identified from the subscription/school status.

## No EVC integration
There is intentionally no EVC gateway integration. The platform owner collects the subscription fee outside the app and records the payment inside the platform.

## Existing database
No new database is required. Existing `subscriptions`, `payments`, `schools`, and related tables are used.
