# School Management System v2 Functional

This version uses the EXISTING Supabase database already created for the project.

## Included now
- Supabase Auth login
- Role selection and profile-role validation
- Super Admin dashboard statistics
- Functional CRUD screens connected to Supabase
- Add / Edit / Delete / Search records
- Students
- Teachers
- Parents
- Schools
- Classes
- Subjects
- Parent-Student relationships
- Class-Student relationships
- Teacher-Subject relationships
- Attendance
- Exams
- Marks & Results
- Fees
- Payments
- Timetable
- Assignments
- Notifications
- Support Tickets
- Subscriptions
- Role-based module visibility
- School-scoped queries for non-Super-Admin users
- GitHub Actions Android APK build
- `flutter analyze` before APK build

## Existing database
Do NOT create a new database and do NOT delete the existing Supabase database.

The project was aligned with the existing column names already verified from the database.

## GitHub Secrets
Create:
- SUPABASE_URL
- SUPABASE_ANON_KEY

The GitHub workflow passes these using `--dart-define`.

## Important security note
The current CRUD layer provides school scoping based on `profiles.school_id`, but production deployment should also have carefully tested table-specific Supabase RLS policies.

## Current authentication
Email/password is implemented through Supabase Auth.
Identifier login (student admission number / teacher code / parent code) requires a secure server-side lookup or Edge Function and is the next authentication hardening step.

## Next hardening
- Server-side identifier login
- Fine-grained teacher/student/parent RLS
- Better relationship dropdowns instead of raw UUID entry
- File uploads
- Push notifications
- Offline sync
- EVC/payment gateway integration
- Automated test suite


## Added in v3 Complete Pack
- Secure identifier-login Edge Function
- Create School + School Admin account Edge Function
- Create Student/Teacher/Parent account Edge Function
- Read-only Supabase security check
- RLS hardening template (not auto-executed)
- Optional GitHub workflow for deploying Edge Functions
- Feature coverage checklist

### Edge Function deployment
For the optional workflow add these GitHub Secrets:
- SUPABASE_PROJECT_REF
- SUPABASE_ACCESS_TOKEN

The APK build still only needs:
- SUPABASE_URL
- SUPABASE_ANON_KEY

### Important
No destructive SQL is included. Existing tables/data are preserved.
The EVC gateway cannot be hard-coded without the actual provider API credentials and API specification.


## Platform billing model
No EVC/payment gateway is required.

The platform owner (Super Admin) controls school registration and subscription billing:
- Super Admin registers the school.
- Super Admin chooses the plan.
- Super Admin sets subscription start/end dates.
- Super Admin records the amount paid.
- Super Admin can mark a school/subscription active, inactive, pending, or expired.
- Schools do not need to connect EVC themselves.

The existing `subscriptions` and `payments` tables are used for this platform-side billing workflow.
