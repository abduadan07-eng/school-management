
-- READ-ONLY SECURITY CHECK
-- Run this first in Supabase SQL Editor. It does NOT change data.
select schemaname, tablename, rowsecurity
from pg_tables
where schemaname='public'
order by tablename;

select schemaname, tablename, policyname, permissive, roles, cmd
from pg_policies
where schemaname='public'
order by tablename, policyname;

-- Check profiles and role distribution:
select role, count(*) from public.profiles group by role order by role;
