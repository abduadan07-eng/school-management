
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  try {
    const { identifier } = await req.json();
    if (!identifier) return new Response(JSON.stringify({error:"identifier required"}), {status:400});

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const profile = await admin.from("profiles")
      .select("id,identifier")
      .eq("identifier", String(identifier).trim())
      .maybeSingle();

    if (profile.error || !profile.data) {
      return new Response(JSON.stringify({error:"Account not found"}), {status:404});
    }

    const user = await admin.auth.admin.getUserById(profile.data.id);
    if (user.error || !user.data.user?.email) {
      return new Response(JSON.stringify({error:"Auth account not found"}), {status:404});
    }

    return new Response(JSON.stringify({email:user.data.user.email}), {
      headers: {"Content-Type":"application/json"}
    });
  } catch (e) {
    return new Response(JSON.stringify({error:String(e)}), {status:500});
  }
});
