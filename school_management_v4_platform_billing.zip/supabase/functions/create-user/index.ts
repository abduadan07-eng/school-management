
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  try {
    const b=await req.json();
    const {email,password,full_name,role,school_id,identifier,entity,entity_data}=b;
    if(!email || !password || !full_name || !role || !school_id || !identifier)
      return new Response(JSON.stringify({error:"email,password,full_name,role,school_id,identifier required"}),{status:400});

    const admin=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const u=await admin.auth.admin.createUser({email,password,email_confirm:true,user_metadata:{full_name,role,school_id}});
    if(u.error) throw u.error;

    const p=await admin.from("profiles").insert({id:u.data.user.id,full_name,role,school_id,identifier,is_active:true});
    if(p.error) throw p.error;

    if(entity && entity_data) {
      const allowed=["students","teachers","parents"];
      if(!allowed.includes(entity)) throw new Error("Unsupported entity");
      const row={...entity_data,school_id,profile_id:u.data.user.id,full_name};
      const e=await admin.from(entity).insert(row);
      if(e.error) throw e.error;
    }

    return new Response(JSON.stringify({user_id:u.data.user.id,identifier,email}),{headers:{"Content-Type":"application/json"}});
  } catch(e) {
    return new Response(JSON.stringify({error:String(e)}),{status:500});
  }
});
