
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

function code(prefix:string, len:number) {
  const chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out=prefix;
  crypto.getRandomValues(new Uint32Array(len)).forEach(n=>out+=chars[n%chars.length]);
  return out;
}

Deno.serve(async (req) => {
  try {
    const body=await req.json();
    const {school_name,admin_name,email,password,phone,location,plan,start_date,end_date}=body;
    if(!school_name || !email || !password) return new Response(JSON.stringify({error:"school_name, email and password are required"}),{status:400});

    const admin=createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const school_code=code("SCH-",7);
    const school_access_code=code("ACC-",8);

    const schoolRes=await admin.from("schools").insert({
      school_name,school_code,school_access_code,phone,location,plan,
      status:"active",start_date,end_date
    }).select("id,school_name,school_code,school_access_code").single();
    if(schoolRes.error) throw schoolRes.error;

    const userRes=await admin.auth.admin.createUser({
      email,password,email_confirm:true,
      user_metadata:{full_name:admin_name,role:"school_admin",school_id:schoolRes.data.id}
    });
    if(userRes.error) throw userRes.error;

    const profileRes=await admin.from("profiles").insert({
      id:userRes.data.user.id,
      full_name:admin_name,
      role:"school_admin",
      school_id:schoolRes.data.id,
      identifier:school_code,
      is_active:true
    });
    if(profileRes.error) throw profileRes.error;

    return new Response(JSON.stringify({
      school:schoolRes.data,
      admin_email:email,
      admin_identifier:school_code
    }),{headers:{"Content-Type":"application/json"}});
  } catch(e) {
    return new Response(JSON.stringify({error:String(e)}),{status:500});
  }
});
