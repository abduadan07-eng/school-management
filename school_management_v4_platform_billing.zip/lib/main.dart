
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(const SchoolApp());
}

SupabaseClient get db => Supabase.instance.client;

enum Role { superAdmin, schoolAdmin, teacher, student, parent }

String roleDb(Role r) => switch (r) {
  Role.superAdmin => 'super_admin',
  Role.schoolAdmin => 'school_admin',
  Role.teacher => 'teacher',
  Role.student => 'student',
  Role.parent => 'parent',
};

String roleLabel(Role r) => switch (r) {
  Role.superAdmin => 'Super Admin',
  Role.schoolAdmin => 'School Admin',
  Role.teacher => 'Teacher',
  Role.student => 'Student',
  Role.parent => 'Parent',
};

class ModuleDef {
  final String title;
  final String table;
  final IconData icon;
  final List<FieldDef> fields;
  final String? orderBy;
  final List<String> searchColumns;
  final bool allowDelete;
  const ModuleDef({
    required this.title,
    required this.table,
    required this.icon,
    required this.fields,
    this.orderBy,
    this.searchColumns = const [],
    this.allowDelete = true,
  });
}

class FieldDef {
  final String name;
  final String label;
  final bool required;
  final bool multiline;
  final bool numeric;
  final bool date;
  const FieldDef(
    this.name,
    this.label, {
    this.required = false,
    this.multiline = false,
    this.numeric = false,
    this.date = false,
  });
}

const commonSchool = FieldDef('school_id', 'School ID');
const studentFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('profile_id', 'Profile ID'),
  FieldDef('admission_number', 'Admission Number', required: true),
  FieldDef('full_name', 'Full Name', required: true),
  FieldDef('gender', 'Gender'),
  FieldDef('date_of_birth', 'Date of Birth', date: true),
  FieldDef('phone', 'Phone'),
  FieldDef('address', 'Address', multiline: true),
  FieldDef('admission_date', 'Admission Date', date: true),
];
const teacherFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('profile_id', 'Profile ID'),
  FieldDef('teacher_code', 'Teacher Code', required: true),
  FieldDef('full_name', 'Full Name', required: true),
  FieldDef('phone', 'Phone'),
  FieldDef('email', 'Email'),
  FieldDef('gender', 'Gender'),
  FieldDef('address', 'Address', multiline: true),
  FieldDef('hire_date', 'Hire Date', date: true),
];
const parentFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('profile_id', 'Profile ID'),
  FieldDef('parent_code', 'Parent Code', required: true),
  FieldDef('full_name', 'Full Name', required: true),
  FieldDef('phone', 'Phone'),
  FieldDef('email', 'Email'),
  FieldDef('address', 'Address', multiline: true),
];
const classFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('class_name', 'Class Name', required: true),
  FieldDef('section', 'Section'),
  FieldDef('class_teacher_id', 'Class Teacher ID'),
  FieldDef('academic_year', 'Academic Year'),
];
const subjectFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('subject_name', 'Subject Name', required: true),
  FieldDef('subject_code', 'Subject Code'),
  FieldDef('description', 'Description', multiline: true),
];
const attendanceFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('student_id', 'Student ID', required: true),
  FieldDef('class_id', 'Class ID'),
  FieldDef('attendance_date', 'Date', required: true, date: true),
  FieldDef('status', 'Status', required: true),
  FieldDef('note', 'Note', multiline: true),
  FieldDef('recorded_by', 'Recorded By'),
];
const examFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('exam_name', 'Exam Name', required: true),
  FieldDef('exam_type', 'Exam Type'),
  FieldDef('academic_year', 'Academic Year'),
  FieldDef('start_date', 'Start Date', date: true),
  FieldDef('end_date', 'End Date', date: true),
  FieldDef('description', 'Description', multiline: true),
];
const markFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('exam_id', 'Exam ID', required: true),
  FieldDef('student_id', 'Student ID', required: true),
  FieldDef('subject_id', 'Subject ID'),
  FieldDef('class_id', 'Class ID'),
  FieldDef('marks', 'Marks', required: true, numeric: true),
  FieldDef('max_marks', 'Max Marks', required: true, numeric: true),
  FieldDef('grade', 'Grade'),
  FieldDef('remark', 'Remark'),
  FieldDef('recorded_by', 'Recorded By'),
];
const feeFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('student_id', 'Student ID', required: true),
  FieldDef('fee_name', 'Fee Name', required: true),
  FieldDef('amount', 'Amount', required: true, numeric: true),
  FieldDef('due_date', 'Due Date', date: true),
  FieldDef('academic_year', 'Academic Year'),
  FieldDef('status', 'Status'),
  FieldDef('description', 'Description', multiline: true),
];
const paymentFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('fee_id', 'Fee ID'),
  FieldDef('student_id', 'Student ID'),
  FieldDef('amount', 'Amount', required: true, numeric: true),
  FieldDef('payment_method', 'Payment Method'),
  FieldDef('transaction_reference', 'Transaction Reference'),
  FieldDef('payment_status', 'Payment Status'),
  FieldDef('paid_at', 'Paid At', date: true),
  FieldDef('recorded_by', 'Recorded By'),
  FieldDef('note', 'Note', multiline: true),
];
const assignmentFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('class_id', 'Class ID'),
  FieldDef('subject_id', 'Subject ID'),
  FieldDef('teacher_id', 'Teacher ID'),
  FieldDef('title', 'Title', required: true),
  FieldDef('description', 'Description', multiline: true),
  FieldDef('due_date', 'Due Date', date: true),
];
const timetableFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('class_id', 'Class ID'),
  FieldDef('subject_id', 'Subject ID'),
  FieldDef('teacher_id', 'Teacher ID'),
  FieldDef('day_of_week', 'Day (1-7)', numeric: true),
  FieldDef('start_time', 'Start Time'),
  FieldDef('end_time', 'End Time'),
  FieldDef('room', 'Room'),
];
const notificationFields = [
  FieldDef('school_id', 'School ID'),
  FieldDef('recipient_profile_id', 'Recipient Profile ID'),
  FieldDef('title', 'Title', required: true),
  FieldDef('message', 'Message', required: true, multiline: true),
  FieldDef('notification_type', 'Type'),
];
const ticketFields = [
  FieldDef('school_id', 'School ID'),
  FieldDef('created_by', 'Created By'),
  FieldDef('title', 'Title', required: true),
  FieldDef('description', 'Description', required: true, multiline: true),
  FieldDef('status', 'Status'),
  FieldDef('priority', 'Priority'),
];
const subscriptionFields = [
  FieldDef('school_id', 'School ID', required: true),
  FieldDef('plan', 'Plan', required: true),
  FieldDef('start_date', 'Start Date', date: true),
  FieldDef('end_date', 'End Date', date: true),
  FieldDef('status', 'Status'),
  FieldDef('amount', 'Amount', numeric: true),
];

final modules = <String, ModuleDef>{
  'schools': ModuleDef(
    title: 'Schools', table: 'schools', icon: Icons.school,
    fields: [
      FieldDef('school_name','School Name',required:true),
      FieldDef('school_code','School Code',required:true),
      FieldDef('school_access_code','School Access Code',required:true),
      FieldDef('phone','Phone'), FieldDef('location','Location'),
      FieldDef('plan','Plan'), FieldDef('status','Status'),
      FieldDef('start_date','Start Date',date:true), FieldDef('end_date','End Date',date:true),
    ],
    orderBy: 'created_at', searchColumns: ['school_name','school_code'],
  ),
  'students': ModuleDef(title:'Students',table:'students',icon:Icons.person,fields:studentFields,orderBy:'created_at',searchColumns:['full_name','admission_number']),
  'teachers': ModuleDef(title:'Teachers',table:'teachers',icon:Icons.person_outline,fields:teacherFields,orderBy:'created_at',searchColumns:['full_name','teacher_code']),
  'parents': ModuleDef(title:'Parents',table:'parents',icon:Icons.family_restroom,fields:parentFields,orderBy:'created_at',searchColumns:['full_name','parent_code']),
  'classes': ModuleDef(title:'Classes',table:'classes',icon:Icons.class_,fields:classFields,orderBy:'created_at',searchColumns:['class_name','section']),
  'subjects': ModuleDef(title:'Subjects',table:'subjects',icon:Icons.menu_book,fields:subjectFields,orderBy:'created_at',searchColumns:['subject_name','subject_code']),
  'attendance': ModuleDef(title:'Attendance',table:'attendance',icon:Icons.fact_check,fields:attendanceFields,orderBy:'attendance_date',searchColumns:['status']),
  'exams': ModuleDef(title:'Exams',table:'exams',icon:Icons.assignment,fields:examFields,orderBy:'start_date',searchColumns:['exam_name','exam_type']),
  'marks': ModuleDef(title:'Marks & Results',table:'marks',icon:Icons.grade,fields:markFields,orderBy:'created_at',searchColumns:['grade','remark']),
  'fees': ModuleDef(title:'Fees',table:'fees',icon:Icons.account_balance_wallet,fields:feeFields,orderBy:'due_date',searchColumns:['fee_name','status']),
  'payments': ModuleDef(title:'Payments',table:'payments',icon:Icons.payments,fields:paymentFields,orderBy:'paid_at',searchColumns:['payment_method','payment_status','transaction_reference']),
  'timetable': ModuleDef(title:'Timetable',table:'timetable',icon:Icons.schedule,fields:timetableFields,orderBy:'day_of_week',searchColumns:['room']),
  'assignments': ModuleDef(title:'Assignments',table:'assignments',icon:Icons.assignment_turned_in,fields:assignmentFields,orderBy:'due_date',searchColumns:['title']),
  'notifications': ModuleDef(title:'Notifications',table:'notifications',icon:Icons.notifications,fields:notificationFields,orderBy:'created_at',searchColumns:['title','message']),
  'support_tickets': ModuleDef(title:'Support Tickets',table:'support_tickets',icon:Icons.support_agent,fields:ticketFields,orderBy:'created_at',searchColumns:['title','status','priority']),
  'subscriptions': ModuleDef(title:'Subscriptions',table:'subscriptions',icon:Icons.card_membership,fields:subscriptionFields,orderBy:'created_at',searchColumns:['plan','status']),
  'parent_students': ModuleDef(title:'Parent ↔ Students',table:'parent_students',icon:Icons.link,fields:[
    FieldDef('school_id','School ID',required:true),FieldDef('parent_id','Parent ID',required:true),FieldDef('student_id','Student ID',required:true),FieldDef('relationship','Relationship'),FieldDef('is_primary','Primary (true/false)')
  ],orderBy:'created_at'),
  'class_students': ModuleDef(title:'Class ↔ Students',table:'class_students',icon:Icons.group,fields:[
    FieldDef('school_id','School ID',required:true),FieldDef('class_id','Class ID',required:true),FieldDef('student_id','Student ID',required:true),FieldDef('academic_year','Academic Year'),FieldDef('joined_at','Joined Date',date:true),FieldDef('is_active','Active (true/false)')
  ],orderBy:'created_at'),
  'teacher_subjects': ModuleDef(title:'Teacher ↔ Subjects',table:'teacher_subjects',icon:Icons.link,fields:[
    FieldDef('school_id','School ID',required:true),FieldDef('teacher_id','Teacher ID',required:true),FieldDef('subject_id','Subject ID',required:true),FieldDef('class_id','Class ID')
  ],orderBy:'created_at'),
};

class SchoolApp extends StatelessWidget {
  const SchoolApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false,
    title:'School Management',
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:Colors.indigo),useMaterial3:true),
    home: const LoginPage(),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState()=>_LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email=TextEditingController(), password=TextEditingController();
  Role selected=Role.schoolAdmin;
  bool loading=false; String? error;
  bool get configured=>supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

  Future<void> login() async {
    setState(()=>loading=true);
    try {
      final res=await db.auth.signInWithPassword(email:email.text.trim(),password:password.text);
      if(res.user==null) throw Exception('Login failed.');
      final p=await db.from('profiles').select().eq('id',res.user!.id).maybeSingle();
      if(p==null) throw Exception('Profile-ka account-kan ma jiro.');
      final actual=p['role'] as String?;
      if(actual!=roleDb(selected)) throw Exception('Dooro role-ka saxda ah: $actual');
      if(!mounted)return;
      Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>HomePage(
        role:selected,profile:Map<String,dynamic>.from(p),
      )));
    } catch(e) { setState(()=>error=e.toString().replaceFirst('Exception: ','')); }
    finally { if(mounted)setState(()=>loading=false); }
  }
  @override void dispose(){email.dispose();password.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    if(!configured)return const Scaffold(body:Center(child:Padding(
      padding:EdgeInsets.all(24),child:Text('Supabase lama xirin. GitHub Actions ku dar SUPABASE_URL iyo SUPABASE_ANON_KEY.',textAlign:TextAlign.center))));
    return Scaffold(
      appBar:AppBar(title:const Text('School Management')),
      body:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:500),child:ListView(
        padding:const EdgeInsets.all(24),shrinkWrap:true,children:[
          const Icon(Icons.school,size:70),const SizedBox(height:12),
          const Text('Login',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold),textAlign:TextAlign.center),
          const SizedBox(height:20),
          DropdownButtonFormField<Role>(value:selected,decoration:const InputDecoration(labelText:'Role',border:OutlineInputBorder()),
            items:Role.values.map((r)=>DropdownMenuItem(value:r,child:Text(roleLabel(r)))).toList(),onChanged:(v)=>setState(()=>selected=v!)),
          const SizedBox(height:12),
          TextField(controller:email,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),
          const SizedBox(height:12),
          TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Password',border:OutlineInputBorder())),
          if(error!=null)Padding(padding:const EdgeInsets.only(top:12),child:Text(error!,style:const TextStyle(color:Colors.red))),
          const SizedBox(height:20),
          FilledButton(onPressed:loading?null:login,child:Text(loading?'Logging in...':'Login')),
        ],
      ))),
    );
  }
}

class HomePage extends StatelessWidget {
  final Role role; final Map<String,dynamic> profile;
  const HomePage({super.key,required this.role,required this.profile});

  List<String> moduleKeys(){
    switch(role){
      case Role.superAdmin:return ['schools','subscriptions','payments','support_tickets','students','teachers','parents'];
      case Role.schoolAdmin:return ['students','teachers','parents','classes','subjects','parent_students','class_students','teacher_subjects','attendance','exams','marks','fees','payments','timetable','assignments','notifications','support_tickets','subscriptions'];
      case Role.teacher:return ['classes','subjects','teacher_subjects','attendance','exams','marks','assignments','timetable','notifications'];
      case Role.student:return ['students','attendance','marks','fees','payments','timetable','assignments','notifications'];
      case Role.parent:return ['parent_students','students','attendance','marks','fees','payments','timetable','assignments','notifications'];
    }
  }
  Future<void> logout(BuildContext context)async{
    await db.auth.signOut();
    if(context.mounted)Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder:(_)=>const LoginPage()),(_)=>false);
  }
  @override Widget build(BuildContext context){
    final keys=moduleKeys();
    return Scaffold(
      appBar:AppBar(title:Text(roleLabel(role)),actions:[IconButton(onPressed:()=>logout(context),icon:const Icon(Icons.logout))]),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Card(child:ListTile(
          leading:const CircleAvatar(child:Icon(Icons.person)),
          title:Text((profile['full_name']??'User').toString()),
          subtitle:Text('${roleLabel(role)}${profile['school_id']==null?'':' • ${profile['school_id']}'}'),
        )),
        const SizedBox(height:12),
        if(role==Role.superAdmin) const _StatStrip(),
        ...keys.where(modules.containsKey).map((k){
          final m=modules[k]!;
          return Card(child:ListTile(leading:Icon(m.icon),title:Text(m.title),trailing:const Icon(Icons.chevron_right),
            onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CrudPage(module:m,profile:profile,role:role)))));
        }),
      ]),
    );
  }
}

class _StatStrip extends StatefulWidget{const _StatStrip();@override State<_StatStrip> createState()=>_StatStripState();}
class _StatStripState extends State<_StatStrip>{
  Future<int> count(String table)async{try{return await db.from(table).count(CountOption.exact);}catch(_){return 0;}}
  @override Widget build(BuildContext context)=>FutureBuilder<List<int>>(
    future:Future.wait([count('schools'),count('students'),count('teachers'),count('parents')]),
    builder:(c,s){final v=s.data??[0,0,0,0];return Card(child:Padding(padding:const EdgeInsets.all(12),child:Wrap(
      spacing:10,runSpacing:10,children:[
        _stat('Schools',v[0]),_stat('Students',v[1]),_stat('Teachers',v[2]),_stat('Parents',v[3])
      ])));});
}
Widget _stat(String title,int n)=>Container(width:145,padding:const EdgeInsets.all(10),child:Column(children:[
  Text('$n',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text(title)
]));

class CrudPage extends StatefulWidget{
  final ModuleDef module; final Map<String,dynamic> profile; final Role role;
  const CrudPage({super.key,required this.module,required this.profile,required this.role});
  @override State<CrudPage> createState()=>_CrudPageState();
}
class _CrudPageState extends State<CrudPage>{
  List<Map<String,dynamic>> rows=[]; bool loading=true; String search='';
  @override void initState(){super.initState();load();}
  String? get schoolId=>widget.profile['school_id']?.toString();

  Future<void> load()async{
    setState(()=>loading=true);
    try{
      dynamic q=db.from(widget.module.table).select();
      if(widget.role!=Role.superAdmin && schoolId!=null && widget.module.table!='schools'){
        q=q.eq('school_id',schoolId!);
      }
      if(widget.module.orderBy!=null)q=q.order(widget.module.orderBy!,ascending:false);
      final data=await q.limit(200);
      setState(()=>rows=List<Map<String,dynamic>>.from(data));
    }catch(e){if(mounted)_msg('Load error: $e');}
    finally{if(mounted)setState(()=>loading=false);}
  }
  List<Map<String,dynamic>> get filtered{
    final s=search.toLowerCase().trim();
    if(s.isEmpty)return rows;
    return rows.where((r)=>widget.module.searchColumns.any((c)=>(r[c]??'').toString().toLowerCase().contains(s))).toList();
  }
  Future<void> remove(Map<String,dynamic> row)async{
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(
      title:const Text('Delete?'),content:const Text('Ma hubtaa inaad tirtirayso record-kan?'),
      actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Delete'))],
    ));
    if(ok!=true)return;
    try{await db.from(widget.module.table).delete().eq('id',row['id']);_msg('Deleted');await load();}
    catch(e){_msg('Delete error: $e');}
  }
  Future<void> save(Map<String,dynamic>? old)async{
    final result=await showDialog<bool>(context:context,builder:(_)=>EditDialog(module:widget.module,old:old,profile:widget.profile));
    if(result==true)await load();
  }
  void _msg(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
  String titleValue(Map<String,dynamic> r){
    for(final k in ['full_name','school_name','class_name','subject_name','exam_name','fee_name','title','admission_number','teacher_code','parent_code','transaction_reference','grade','status']){
      if(r[k]!=null&&r[k].toString().isNotEmpty)return r[k].toString();
    }
    return r['id']?.toString()??'Record';
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(widget.module.title),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),
    floatingActionButton:FloatingActionButton.extended(onPressed:()=>save(null),icon:const Icon(Icons.add),label:const Text('Add')),
    body:Column(children:[
      Padding(padding:const EdgeInsets.all(12),child:TextField(
        decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search...',border:OutlineInputBorder()),
        onChanged:(v)=>setState(()=>search=v),
      )),
      Expanded(child:loading?const Center(child:CircularProgressIndicator()):filtered.isEmpty
        ?const Center(child:Text('No records found'))
        :ListView.builder(itemCount:filtered.length,itemBuilder:(c,i){
          final r=filtered[i];
          final subtitle=r.entries.where((e)=>e.key!='id'&&e.value!=null&&e.value.toString().isNotEmpty).take(3).map((e)=>'${e.key}: ${e.value}').join(' • ');
          return Card(child:ListTile(
            leading:CircleAvatar(child:Icon(widget.module.icon,size:20)),
            title:Text(titleValue(r)),subtitle:Text(subtitle,maxLines:2,overflow:TextOverflow.ellipsis),
            trailing:PopupMenuButton<String>(onSelected:(v){if(v=='edit')save(r);if(v=='delete')remove(r);},
              itemBuilder:(_)=>[const PopupMenuItem(value:'edit',child:Text('Edit')),if(widget.module.allowDelete)const PopupMenuItem(value:'delete',child:Text('Delete'))]),
          ));
        })),
    ]),
  );
}

class EditDialog extends StatefulWidget{
  final ModuleDef module; final Map<String,dynamic>? old; final Map<String,dynamic> profile;
  const EditDialog({super.key,required this.module,required this.old,required this.profile});
  @override State<EditDialog> createState()=>_EditDialogState();
}
class _EditDialogState extends State<EditDialog>{
  final Map<String,TextEditingController> ctrls={}; bool saving=false;
  @override void initState(){
    super.initState();
    for(final f in widget.module.fields){
      var val=widget.old?[f.name];
      if(val is bool)val=val.toString();
      ctrls[f.name]=TextEditingController(text:val?.toString()??'');
      if(widget.old==null && f.name=='school_id' && widget.profile['school_id']!=null){
        ctrls[f.name]!.text=widget.profile['school_id'].toString();
      }
    }
  }
  @override void dispose(){for(final c in ctrls.values)c.dispose();super.dispose();}
  dynamic parse(FieldDef f,String s){
    if(s.trim().isEmpty)return null;
    if(f.numeric)return num.tryParse(s.trim());
    if(f.name=='is_active'||f.name=='is_primary')return s.trim().toLowerCase()=='true';
    return s.trim();
  }
  Future<void> submit()async{
    final data=<String,dynamic>{};
    for(final f in widget.module.fields){
      final v=parse(f,ctrls[f.name]!.text);
      if(f.required && v==null){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${f.label} waa required')));return;}
      if(v!=null)data[f.name]=v;
    }
    setState(()=>saving=true);
    try{
      if(widget.old==null){
        await db.from(widget.module.table).insert(data);
      }else{
        await db.from(widget.module.table).update(data).eq('id',widget.old!['id']);
      }
      if(mounted)Navigator.pop(context,true);
    }catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Save error: $e')));
    }finally{if(mounted)setState(()=>saving=false);}
  }
  @override Widget build(BuildContext context)=>AlertDialog(
    title:Text(widget.old==null?'Add ${widget.module.title}':'Edit ${widget.module.title}'),
    content:SizedBox(width:500,child:SingleChildScrollView(child:Column(
      mainAxisSize:MainAxisSize.min,
      children:widget.module.fields.map((f)=>Padding(
        padding:const EdgeInsets.only(bottom:10),
        child:TextField(
          controller:ctrls[f.name],maxLines:f.multiline?3:1,
          keyboardType:f.numeric?const TextInputType.numberWithOptions(decimal:true):TextInputType.text,
          decoration:InputDecoration(labelText:f.label,suffixText:f.date?'YYYY-MM-DD':null,border:const OutlineInputBorder()),
        ),
      )).toList(),
    ))),
    actions:[
      TextButton(onPressed:saving?null:()=>Navigator.pop(context,false),child:const Text('Cancel')),
      FilledButton(onPressed:saving?null:submit,child:Text(saving?'Saving...':'Save')),
    ],
  );
}
