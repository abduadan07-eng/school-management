# School Management – Coverage Checklist

## Core
- [x] Supabase URL/anon key through build-time environment
- [x] Email/password Auth
- [x] Role validation
- [x] Logout
- [x] Existing database preserved
- [x] CRUD + search
- [x] School-scoped reads for non-super-admin roles

## Super Admin
- [x] Schools
- [x] Subscriptions
- [x] Payments
- [x] Support tickets
- [x] Platform statistics
- [x] Create-school Edge Function
- [x] Platform-owned school registration
- [x] Subscription plan/start/end dates
- [x] Manual school payment recording
- [x] School admin account creation Edge Function

## School Admin
- [x] Students
- [x] Teachers
- [x] Parents
- [x] Classes
- [x] Subjects
- [x] Parent/student links
- [x] Class/student links
- [x] Teacher/subject links
- [x] Attendance
- [x] Exams
- [x] Marks/results
- [x] Fees
- [x] Payments
- [x] Timetable
- [x] Assignments
- [x] Notifications
- [x] Support tickets
- [x] Subscriptions

## Teacher
- [x] Classes
- [x] Subjects
- [x] Teacher/subject assignment
- [x] Attendance
- [x] Exams
- [x] Marks
- [x] Assignments
- [x] Timetable
- [x] Notifications

## Student
- [x] Student record
- [x] Attendance
- [x] Marks/results
- [x] Fees
- [x] Payments
- [x] Timetable
- [x] Assignments
- [x] Notifications

## Parent
- [x] Parent/student relationship
- [x] Children records
- [x] Attendance
- [x] Marks/results
- [x] Fees
- [x] Payments
- [x] Timetable
- [x] Assignments
- [x] Notifications

## Security / future-ready infrastructure
- [x] Identifier-login Edge Function
- [x] Create school Edge Function
- [x] Create student/teacher/parent account Edge Function
- [x] Read-only security inspection SQL
- [x] RLS hardening template
- [ ] Final production RLS policies must be reviewed against the exact existing policies
- [x] No EVC gateway required — Super Admin manually records school subscription/payment
- [ ] Push notification provider credentials required for optional push notifications
- [ ] Offline sync requires local database + conflict strategy
